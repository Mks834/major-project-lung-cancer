# **HackNYU**
___
Lung Cancer Detection (LCD)
Team Member:
* Yichen Gong
- Shining
+ Yamei
___
[Decpost/LCD](https://devpost.com/software/lung-cancer-detection-using-deep-learning)
